SECRET_KEY = '99+)1jm(luf6_uup@+=(3e^(*8skm_ez%cykfmn9@e3c_!(#+i'

users = [
('Samarth Jain', 'f20160487'),
('Sarthak Agarwal', 'f20160511'),
]